options_trader
===============

asset_account
--------------

.. automodule:: finfactory.options_trader.asset_account

.. currentmodule:: finfactory.options_trader.asset_account

AssetAccount
^^^^^^^^^^^^^

.. autoclass:: finfactory.options_trader.asset_account.AssetAccount
    :members:
    :undoc-members:
    :show-inheritance:

basic_config
-------------

.. automodule:: finfactory.options_trader.basic_config

.. currentmodule:: finfactory.options_trader.basic_config

OptsConfig
^^^^^^^^^^^

.. autoclass:: finfactory.options_trader.basic_config.OptsConfig
    :members:
    :undoc-members:
    :show-inheritance:

ETFsConfig
^^^^^^^^^^^

.. autoclass:: finfactory.options_trader.basic_config.ETFsConfig
    :members:
    :undoc-members:
    :show-inheritance:

strategy_target_multiple
-------------------------

.. automodule:: finfactory.options_trader.strategy_target_multiple

.. currentmodule:: finfactory.options_trader.strategy_target_multiple

OptsTrader
^^^^^^^^^^^

.. autoclass:: finfactory.options_trader.strategy_target_multiple.OptsTrader
    :members:
    :undoc-members:
    :show-inheritance:

utils_opts
-----------

.. automodule:: finfactory.options_trader.utils_opts

.. currentmodule:: finfactory.options_trader.utils_opts

cal_opt_vol_to_buy
^^^^^^^^^^^^^^^^^^^

.. autofunction:: finfactory.options_trader.utils_opts.cal_opt_vol_to_buy

cal_opt_vol_to_sel
^^^^^^^^^^^^^^^^^^^

.. autofunction:: finfactory.options_trader.utils_opts.cal_opt_vol_to_sel

cal_opt_vol_to_buy_new
^^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: finfactory.options_trader.utils_opts.cal_opt_vol_to_buy_new
