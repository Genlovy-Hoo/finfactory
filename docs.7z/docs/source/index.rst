Welcome to FinFactory's documentation!
=======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   finfactory <finfactory>
   factors <finfactory.factors>
   finplot <finfactory.finplot>
   fintools <finfactory.fintools>
   get_data <finfactory.get_data>
   options_trader <finfactory.options_trader>
   strategy <finfactory.strategy>
   utils <finfactory.utils>

Indices and tables
===================

* :ref:`genindex`
* :ref:`modindex`
